                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1825825
Guide tige filetée Discoeasy 200 by Asphyth is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Guide pour tige filetée pour Discoeasy 200 de Dagoma.

Vous venez de passer sur la Discoeasy ? Du wobble ? Déçu que Dagoma ai enlevé les guides présent sur sa Discovery 200 ? Cette pièce est faite pour vous !

Permet une fixation sans réimpression des deux pièces 13 et 13a du haut de la DE200.

Retirez les boulons, placez la pièce, placez les boulons, serrez, le tour est joué.

Pièce a imprimer avec les emplacement boulons vers le haut (comme présenté sur la photo), avec des supports sur plateau, 0.15mm conseillé.

Info : diametre trou tige filetée : 8,75mm

Info montage : Montez votre charriot d'impression tout en haut, installez les antiwobble, si ca bloque = oubliez ca, l'une de vos tige est trop tordue ! (+1,5mm de différence)

Edit 19/11/2016 : Je viens de sortir un v2 avec un deport plus important, je me suis rendu compte que je m'étais basé sur les cotes de la D200 et non pas la DE200, vous ne devriez plus avoir ce blocage !!!
Je conseil a ceux ayant imprimer la v1 de faire monter leur chariot au maximum de la hauteur : si blocage = impression de la v2, si blocage a nouveau alors les tiges sont tordues !

# Print Settings

Printer: Dagoma Discoeasy 200
Rafts: No
Supports: Yes
Resolution: .15
Infill: 100%